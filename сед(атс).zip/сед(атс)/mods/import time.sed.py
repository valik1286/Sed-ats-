import time
import sys
import re

# COMMAND NAME
COMMAND_NAME = "кодування"

def to_binary_string(n, min_len=0):
    """Конвертує десяткове число в двійковий рядок."""
    return format(n, f'0{min_len}b')

def print_binary_operation(num1_dec, num2_dec, operator, result_dec):
    """
    Виводить арифметичну операцію в консоль, показуючи двійкові числа.
    """
    max_len = max(len(to_binary_string(num1_dec)), len(to_binary_string(num2_dec)), len(to_binary_string(result_dec)))

    num1_bin = to_binary_string(num1_dec, max_len)
    num2_bin = to_binary_string(num2_dec, max_len)
    result_bin = to_binary_string(result_dec, max_len)

    print(f"  {num1_bin}  ({num1_dec})")
    print(f"{operator} {num2_bin}  ({num2_dec})")
    print("-" * (max_len + 5))
    print(f"  {result_bin}  ({result_dec})")

def run_plugin():
    print("Виберіть режим:")
    print("1 - Кодування тексту в двійковий код")
    print("2 - Розкодування двійкового коду в текст")
    print("3 - Арифметичні дії в двійковій системі")
    mode = input("Введіть 1, 2 або 3: ")

    if mode == "1":
        print("Введіть текст для кодування (3 порожні Enter поспіль = завершення):")
        lines = []
        empty_count = 0
        while True:
            line = input()
            if line.strip() == "":
                empty_count += 1
                if empty_count == 3:
                    break
            else:
                lines.append(line)
                empty_count = 0
        text = "\n".join(lines)
        binary = ' '.join(format(ord(char), '08b') for char in text)
        print("Закодований текст:")
        print(binary)

    elif mode == "2":
        print("Введіть двійковий код (байти через пробіл, 3 порожні Enter поспіль = завершення):")
        lines = []
        empty_count = 0
        while True:
            line = input()
            if line.strip() == "":
                empty_count += 1
                if empty_count == 3:
                    break
            else:
                lines.append(line)
                empty_count = 0
        binary = " ".join(lines)
        try:
            chars = [chr(int(b, 2)) for b in binary.split()]
            decoded_text = ''.join(chars)
            print("Розкодований текст:")
            print(decoded_text)
        except Exception as e:
            print("Помилка розкодування:", e)

    elif mode == "3":
        print("Введіть вираз у форматі: число1 оператор число2 [оператор число3...](.). Приклад: 48-23-392(.)")
        print("Доступні операції: +, -, *, /")
        user_input = input("> ").strip()
        
        # Регулярний вираз для пошуку всіх чисел та операторів
        expression_parts = re.findall(r"(\d+|[+\-*/])", user_input.replace("(.)", ""))

        if not expression_parts or len(expression_parts) < 3 or len(expression_parts) % 2 == 0:
            print("Неправильний формат введення.")
            return

        try:
            # Початкове значення - перше число у списку
            result = int(expression_parts[0])

            # Проходимо по решті списку парами: оператор, число
            for i in range(1, len(expression_parts), 2):
                operator = expression_parts[i]
                next_num = int(expression_parts[i+1])

                prev_result = result
                
                # Виконуємо операцію
                if operator == "+":
                    result += next_num
                elif operator == "-":
                    result -= next_num
                elif operator == "*":
                    result *= next_num
                elif operator == "/":
                    if next_num == 0:
                        print("Ділення на нуль неможливе.")
                        return
                    if prev_result % next_num != 0:
                        print("Для ділення підтримуються лише цілі числа без залишку.")
                        return
                    result //= next_num
                
                # Виводимо проміжний результат
                print_binary_operation(prev_result, next_num, operator, result)
                print("---")

        except ValueError:
            print("Будь ласка, введіть дійсні числа.")
        except IndexError:
            print("Неправильна кількість чисел або операторів у виразі.")
        except Exception as e:
            print(f"Сталася помилка: {e}")
            
    else:
        print("Невірний вибір режиму.")