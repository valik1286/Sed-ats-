import random

COMMAND_NAME = "worldgen"

def run_plugin(args=None):
    print("=== World Generator ===")
    try:
        width = int_input("Введи ширину карти: ")
        height = int_input("Введи висоту карти: ")
        land_chance = float_input("Шанс суші (0-1, наприклад 0.4): ")

        world = generate_world(width, height, land_chance)
        show_world(world)

    except Exception as e:
        print(f"Сталася помилка: {e}")

def int_input(prompt):
    value = input(prompt)
    try:
        return int(value)
    except ValueError:
        raise ValueError(f"Неправильне число: '{value}'. Очікувалось ціле число.")

def float_input(prompt):
    value = input(prompt).replace(',', '.')  # дозволяємо кому
    try:
        result = float(value)
        if not 0 <= result <= 1:
            raise ValueError(f"Число поза діапазоном 0-1: {result}")
        return result
    except ValueError:
        raise ValueError(f"Неправильне число: '{value}'. Очікувалось число від 0 до 1 (можна використовувати крапку або кому).")

def generate_world(width, height, land_chance=0.4):
    """Генерує карту світу з сушею та водою"""
    return [[1 if random.random() < land_chance else 0 for _ in range(width)] for _ in range(height)]

def show_world(world):
    """Виводить карту у консоль"""
    for row in world:
        line = "".join("█" if cell else "□" for cell in row)
        print(line)
