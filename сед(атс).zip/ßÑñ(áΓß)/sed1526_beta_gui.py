#!/usr/bin/env python3
# sed1526_beta.py — інтегрований Sed 1.5.2.6 beta + GUI + SSA
# Автор: згенеровано по техзавданню користувача (valik1286)
# Примітка: працює тільки зі стандартними бібліотеками Python (tkinter, json, logging, ast, importlib та ін.)

import os
import sys
import json
import re
import ast
import time
import datetime
import importlib.util
import threading
import traceback
from pathlib import Path
import logging
import queue

try:
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox, simpledialog
except Exception:
    print("tkinter не доступний. Встанови Python з tkinter.")
    raise

# ----------------- Константи і шляхи -----------------
AI_NAME = "Sed"
VERSION = "1.5.2.6 beta"
AUTHOR = "valik1286"

ISED_LIBRARY_FILE = "ised.txt"
LEARNED_DATA_FILE = "learned_data.json"
UNKNOWN_DATA_FILE = "unknown_data.json"
ARCHIVE_FILE = os.path.join("mods", "архів.txt")
CHAT_LOG_FILE = "chat_log.txt"
MODS_FOLDER = "mods"
ATSED_FILE = "atsed.txt"
SECURITY_LOG_FILE = "security_log.txt"

LOGS_DIR = Path("logs")
LOGS_DIR.mkdir(parents=True, exist_ok=True)
SYSTEM_LOG_FILE = LOGS_DIR / "system.log"

CONFIG_FILE = Path("config.json")

# Security constants (з твого коду)
TIMEOUT_BEFORE_AUTH = 120
AUTH_TIMEOUT = 300
SECURITY_PASSWORD = "1486"
SECURITY_VERSION = "sed1.3.2"
SECURITY_COMMAND = "connect sed"

# ----------------- Глобальні структури -----------------
chat_history = []
learned_data = {}
ised_data = {}
atsed_data = {}
unknown_data = {}
mods_data = {}      # для .sed/.txt словників (ключ->відповідь)
code_mods = {}      # команда -> callable (з .sed.py)
python_modules = {} # імпортовані .py модулі
sed_has_code_error = False

# ----------------- Налаштування логування (файл) -----------------
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(SYSTEM_LOG_FILE, encoding="utf-8"),
        logging.StreamHandler(sys.stdout)
    ]
)

# ----------------- Теми (кольори для GUI) -----------------
THEMES = {
    "light": {
        "bg": "#ffffff", "fg": "#000000", "accent": "#2b7cff",
        "code_bg": "#ffffff", "code_good": "#ddffdd", "code_bad": "#ffdddd", "button_bg": "#f0f0f0"
    },
    "dark": {
        "bg": "#2e2e2e", "fg": "#f2f2f2", "accent": "#5fa8ff",
        "code_bg": "#1e1e1e", "code_good": "#274627", "code_bad": "#4a2626", "button_bg": "#3a3a3a"
    },
    "techno": {
        "bg": "#000000", "fg": "#00ff6a", "accent": "#00ff6a",
        "code_bg": "#000000", "code_good": "#003300", "code_bad": "#330000", "button_bg": "#0b0b0b"
    }
}

# ----------------- Утиліти для config -----------------
def load_config():
    default = {"theme": "light", "mods_dir": MODS_FOLDER, "left_visible": True, "mode": "Користувач"}
    if CONFIG_FILE.exists():
        try:
            cfg = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            for k, v in default.items():
                if k not in cfg:
                    cfg[k] = v
            return cfg
        except Exception:
            logging.exception("Не вдалося прочитати config.json. Використовуються налаштування за замовчуванням.")
            return default
    else:
        return default

def save_config(cfg):
    try:
        CONFIG_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        logging.exception("Не вдалося зберегти config.json")

# ----------------- Вивід (GUI + лог) -----------------
# Для безпечного виводу з різних потоків використовуємо чергу
_print_queue = queue.Queue()

def queued_printer_worker(text_widget, stop_event, theme_name_getter):
    """Потік, який читає з черги і пише у текстовий віджет."""
    while not stop_event.is_set():
        try:
            item = _print_queue.get(timeout=0.1)
        except queue.Empty:
            continue
        try:
            text, tag = item
            # обробка теми: techno додає //, dark прибирає //
            theme = theme_name_getter()
            if theme == "techno":
                if not text.startswith("//"):
                    text_to_show = "// " + text
                else:
                    text_to_show = text
            elif theme == "dark":
                # прибираємо провісник //
                text_to_show = re.sub(r"^//\s*", "", text)
            else:
                text_to_show = text

            # вставляємо в GUI (якщо віджет існує)
            try:
                text_widget.configure(state="normal")
                text_widget.insert(tk.END, text_to_show + "\n", tag)
                text_widget.see(tk.END)
                text_widget.configure(state="disabled")
            except Exception:
                # у випадку, якщо GUI ще не готовий — падає у лог
                pass

            # й також запис у system.log (через logging)
            if tag == "err":
                logging.error(text)
            elif tag == "debug":
                logging.debug(text)
            else:
                logging.info(text)
        except Exception:
            logging.exception("Error in queued_printer_worker")

def sed_print(msg, tag="info"):
    """Поміщає рядок у чергу для друку та в системний logger."""
    try:
        _print_queue.put((str(msg), tag))
    except Exception:
        logging.exception("Не вдалося поставити в чергу повідомлення: %s", msg)

# ----------------- Функції завантаження/збереження даних (як у твоєму коді) -----------------
def load_data(filepath, as_regex=False):
    data = {}
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line and ':' in line:
                    key, value = line.split(':', 1)
                    key = key.strip()
                    if as_regex:
                        try:
                            pattern = re.compile(key, re.IGNORECASE)
                            data[pattern] = value.strip()
                        except re.error:
                            # невалидний regex — зберігаємо як простий ключ
                            data[key] = value.strip()
                    else:
                        data[key.lower()] = value.strip()
    except FileNotFoundError:
        sed_print(f"DEBUG: Файл бібліотеки '{filepath}' не знайдено. Продовжую без нього.", "debug")
    except Exception as e:
        sed_print(f"DEBUG: Помилка завантаження '{filepath}': {e}", "err")
    return data

def load_json_safe(path):
    try:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
    except json.JSONDecodeError:
        sed_print(f"DEBUG: Файл '{path}' пошкоджений або порожній. Створюю новий.", "err")
    except Exception as e:
        sed_print(f"DEBUG: Помилка завантаження JSON '{path}': {e}", "err")
    return {}

def save_json_safe(path, data):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        sed_print(f"DEBUG: Помилка збереження '{path}': {e}", "err")

def append_to_archive(word, meaning, explanation=""):
    try:
        os.makedirs(MODS_FOLDER, exist_ok=True)
        with open(ARCHIVE_FILE, "a", encoding="utf-8") as f:
            line = f"{word}/{meaning}"
            if explanation:
                line += f"/{explanation}"
            f.write(line + "\n")
    except Exception as e:
        sed_print(f"DEBUG: Помилка запису в архів '{ARCHIVE_FILE}': {e}", "err")

# ----------------- Завантаження модів (адаптовано під GUI) -----------------
def load_mods(mods_folder=MODS_FOLDER):
    global mods_data, code_mods, python_modules
    mods_data, code_mods, python_modules = {}, {}, {}
    if not os.path.exists(mods_folder):
        os.makedirs(mods_folder, exist_ok=True)
        sed_print(f"DEBUG: Папку '{mods_folder}' створено.", "debug")
        return

    for fn in sorted(os.listdir(mods_folder)):
        path = os.path.join(mods_folder, fn)
        if os.path.isfile(path):
            try:
                if fn.endswith(".sed") or fn.endswith(".txt"):
                    sed_print(f"DEBUG: Завантажую словниковий мод: {fn}", "debug")
                    d = load_data(path)
                    # merge
                    for k, v in d.items():
                        mods_data[k] = v
                elif fn.endswith(".sed.py"):
                    sed_print(f"DEBUG: Завантажую кодовий мод: {fn}", "debug")
                    # load as module
                    name = fn[:-len(".sed.py")]
                    try:
                        spec = importlib.util.spec_from_file_location(name, path)
                        mod = importlib.util.module_from_spec(spec)
                        spec.loader.exec_module(mod)
                        if hasattr(mod, 'COMMAND_NAME') and hasattr(mod, 'run_plugin'):
                            code_mods[mod.COMMAND_NAME.lower()] = mod.run_plugin
                            sed_print(f"DEBUG: Завантажено кодовий мод: {name}", "debug")
                        else:
                            sed_print(f"DEBUG: Кодовый мод {fn} не має COMMAND_NAME/run_plugin", "err")
                    except Exception as e:
                        sed_print(f"❌ Помилка імпорту кодового моду '{fn}': {e}", "err")
                elif fn.endswith(".py"):
                    sed_print(f"DEBUG: Завантажую Python-модуль: {fn}", "debug")
                    try:
                        module_name = fn[:-3]
                        spec = importlib.util.spec_from_file_location(module_name, path)
                        module = importlib.util.module_from_spec(spec)
                        spec.loader.exec_module(module)
                        python_modules[module_name] = module
                        sed_print(f"DEBUG: Завантажено Python-модуль: {module_name}", "debug")
                    except Exception as e:
                        sed_print(f"❌ Помилка імпорту Python-модуля '{fn}': {e}", "err")
                else:
                    # невідомий формат — ігноруємо
                    pass
            except Exception as e:
                sed_print(f"❌ Невідома помилка при обробці файлу {fn}: {e}", "err")

# ----------------- Допоміжні функції ядра (взято і адаптовано з твого коду) -----------------
def is_code_safe(code_content):
    dangerous_patterns = {
        r"\bos\.remove\b": "видалення файлів (os.remove)",
        r"\bos\.system\b": "виконання системних команд (os.system)",
        r"\bshutil\.rmtree\b": "рекурсивне видалення директорій (shutil.rmtree)",
        r"\bsubprocess\.run\b": "запуск зовнішніх процесів (subprocess.run)",
        r"\bsubprocess\.call\b": "запуск зовнішніх процесів (subprocess.call)",
        r"\bsys\.exit\b": "аварійне завершення програми (sys.exit)",
        r"\bimport\s+os\b": "імпорт модуля 'os'",
        r"\bimport\s+shutil\b": "імпорт модуля 'shutil'",
        r"\bimport\s+subprocess\b": "імпорт модуля 'subprocess'",
        r"\bimport\s+sys\b": "імпорт модуля 'sys' (для sys.exit)",
        r"open\(.*['\"]w['\"].*\)": "відкриття файлу в режимі запису ('w')",
        r"open\(.*['\"]a['\"].*\)": "відкриття файлу в режимі дозапису ('a')",
        r"open\(.*['\"]x['\"].*\)": "відкриття файлу в режимі ексклюзивного створення ('x')",
        r"\beval\(": "виконання рядка як коду (eval)",
        r"\bexec\(": "виконання рядка як коду (exec)",
    }
    for pattern, reason in dangerous_patterns.items():
        if re.search(pattern, code_content, re.IGNORECASE):
            if "open(" in pattern:
                if not re.search(r"open\(.*['\"]r['\"].*\)", code_content, re.IGNORECASE):
                    return False, f"Виявлено потенційно небезпечну операцію: {reason}"
            else:
                return False, f"Виявлено потенційно небезпечну операцію: {reason}"
    if "del os" in code_content or "del shutil" in code_content or "del subprocess" in code_content:
        return False, "Виявлено спробу видалення системного модуля."
    return True, "Код безпечний для створення."

def clear_system_log():
    try:
        with open(SYSTEM_LOG_FILE, "w", encoding="utf-8") as f:
            f.write("")
        sed_print("Sed: Лог успішно очищено.", "debug")
    except Exception as e:
        sed_print(f"Sed: Помилка очищення логу: {e}", "err")

def append_security_log(line):
    try:
        with open(SECURITY_LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {line}\n")
    except Exception:
        logging.exception("Не вдалося записати security log")

# ----------------- Core: відповіді (get_response) -----------------
def find_approximate_response(msg):
    for key_unknown, val_unknown in unknown_data.items():
        if key_unknown and re.search(r'\b' + re.escape(key_unknown) + r'\b', msg, re.IGNORECASE):
            return val_unknown if val_unknown else None
    return None

def number_to_words(n):
    words = {
        0: "нуль", 1: "один", 2: "два", 3: "три", 4: "чотири", 5: "п'ять",
        6: "шість", 7: "сім", 8: "вісім", 9: "дев'ять", 10: "десять",
        11: "одинадцять", 12: "дванадцять", 13: "тринадцять", 14: "чотирнадцять",
        15: "п'ятнадцять", 16: "шістнадцять", 17: "сімнадцять", 18: "вісімнадцять",
        19: "дев'ятнадцять", 20: "двадцять"
    }
    return words.get(n, str(n))

def calculate_expression(expr):
    try:
        allowed_chars = "0123456789+-*/.() "
        if any(c not in allowed_chars for c in expr):
            return None
        result = eval(expr, {"__builtins__":None}, {})
        if isinstance(result, (int, float)):
            if int(result) == result:
                return number_to_words(int(result))
            else:
                return str(round(result, 4))
        else:
            return None
    except Exception as e:
        sed_print(f"DEBUG: Помилка обчислення виразу '{expr}': {e}", "err")
        return None

def show_mod_code(mod_name, mods_folder=MODS_FOLDER, max_lines=400):
    file_path = os.path.join(mods_folder, mod_name)
    if not os.path.exists(file_path):
        return f"Sed: Файл '{mod_name}' не знайдено."
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        total_lines = len(lines)
        if total_lines > max_lines:
            return f"Sed: Код дуже великий ({total_lines} рядків). Перегляд заборонено."
        code = "".join(lines)
        return f"Sed: Код моду '{mod_name}':\n" + code
    except Exception as e:
        return f"Sed: Помилка читання файлу '{mod_name}': {e}"

# Основна логіка відповіді (адаптована)
def get_response(msg):
    global sed_has_code_error
    msg_l = msg.lower().strip()
    chat_history.append(msg)
    current_time_str_full = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    current_time_str_short = datetime.datetime.now().strftime("%H:%M")

    # Системні команди (короткі)
    if msg_l == "очисти лог" or msg_l == "очисти лог.":
        clear_system_log()
        return "Sed: Лог очищено."

    if msg_l.startswith("список модів"):
        return list_mods_text()

    if msg_l.startswith("видали мод"):
        parts = msg_l.split()
        if len(parts) > 2:
            identifier = parts[2]
            delete_mod(identifier)
            return f"Sed: Спроба видалити мод '{identifier}'."
        else:
            # сформувати список для вибору
            files = [f for f in sorted(os.listdir(MODS_FOLDER)) if f.endswith((".py",".sed",".sed.py",".txt"))]
            if not files:
                return "Sed: Моди не знайдено для видалення."
            output = ["Список модів для видалення:"]
            for i, f in enumerate(files, 1):
                output.append(f"{i}. {f}")
            output.append("Введіть 'видали мод <номер або назва>'")
            return "\n".join(output)

    if msg_l.startswith("показати код"):
        parts = msg.split(maxsplit=2)
        if len(parts) > 2:
            return show_mod_code(parts[2])
        else:
            return "Sed: Вкажи назву файлу."

    if msg_l == "вийти":
        return "До побачення!"

    if msg_l == "допомога":
        help_text = (
            "Команди:\n"
            "- вийти\n"
            "- допомога\n"
            "- перезавантажся\n"
            "- аналіз (аналізує незрозумілі запити з поточної сесії)\n"
            "- автотренування (аналізує лог чату для навчання)\n"
            "- навчи [слово] це [значення]\n"
            "- забудь [слово]\n"
            "- список модів\n"
            "- створити [назва] [формат] [код]\n"
            "- connect ats\n"
            "- очисти лог\n            "
        )
        if code_mods:
            help_text += "\nДоступні команди кодових модів:\n"
            for cmd in code_mods.keys():
                help_text += f"- {cmd}\n"
        return help_text

    if msg_l == "перезавантажся":
        simulate_reboot()
        return "Sed: Перезавантаження завершено."

    if msg_l == "connect ats":
        simulate_ats_connection_failure()
        return "Sed: Підключення не вдалося (імітація)."

    if msg_l == "аналіз":
        # запускає тот самий аналіз, що і кнопка 📑
        result_summary = run_system_analyzer()
        return result_summary

    if msg_l == "автотренування":
        analyze_log_for_learning()
        return "Sed: Автотренування завершено."

    # навчи
    learn_match = re.match(r"навчи\s+(.+?)\s+це\s+(.+)", msg, re.IGNORECASE | re.DOTALL)
    if learn_match:
        word = learn_match.group(1).strip().lower()
        meaning = learn_match.group(2).strip()
        learned_data[word] = meaning
        save_json_safe(LEARNED_DATA_FILE, learned_data)
        append_to_archive(word, meaning)
        resp = f"Sed: Зрозумів! '{word}' тепер означає '{meaning}'."
        if sed_has_code_error:
            resp += " error code..."
        return resp

    # забудь
    forget_match = re.match(r"забудь\s+(.+)", msg_l)
    if forget_match:
        word_to_forget = forget_match.group(1).strip()
        if word_to_forget in learned_data:
            del learned_data[word_to_forget]
            save_json_safe(LEARNED_DATA_FILE, learned_data)
            return f"Sed: Забув '{word_to_forget}'."
        elif word_to_forget in unknown_data:
            del unknown_data[word_to_forget]
            save_json_safe(UNKNOWN_DATA_FILE, unknown_data)
            return f"Sed: Видалив '{word_to_forget}' зі списку незрозумілих фраз."
        else:
            return f"Sed: '{word_to_forget}' не знайдено."

    # створити файл
    create_match = re.match(r"створи\s+([^\s]+)\s+([^\s]+)\s+(.+)", msg, re.IGNORECASE | re.DOTALL)
    if create_match:
        file_name = create_match.group(1)
        file_format_input = create_match.group(2).lower()
        content_to_save = create_match.group(3)
        allowed_formats = ["py", "sedpy", "txt", "sed"]
        if file_format_input not in allowed_formats:
            return f"Sed: Непідтримуваний формат '{file_format_input}'. Дозволені: {', '.join(allowed_formats)}."
        full_file_name = f"{file_name}.{file_format_input}"
        file_path_for_creation = os.path.join(MODS_FOLDER, full_file_name)
        is_safe = True
        reason = "OK"
        if file_format_input in ("py", "sedpy"):
            is_safe, reason = is_code_safe(content_to_save)
        if not is_safe:
            append_security_log(f"Security block on create {full_file_name}: {reason}")
            return f"Sed: Неможливо зберегти '{full_file_name}'. Причина: {reason}"
        try:
            os.makedirs(MODS_FOLDER, exist_ok=True)
            if file_format_input == "sedpy":
                final_save_name = f"{file_name}.sed.py"
                final_file_path = os.path.join(MODS_FOLDER, final_save_name)
                with open(final_file_path, "w", encoding="utf-8") as f:
                    f.write(content_to_save)
                load_mods()
                return f"Sed: Кодовий мод '{final_save_name}' створено та завантажено."
            else:
                with open(file_path_for_creation, "w", encoding="utf-8") as f:
                    f.write(content_to_save)
                load_mods()
                return f"Sed: Файл '{full_file_name}' створено та завантажено."
        except Exception as e:
            sed_print(f"DEBUG: Помилка збереження файлу {full_file_name}: {e}", "err")
            return f"Sed: Помилка при збереженні '{full_file_name}': {e}"

    # Арифметика
    calc_result = calculate_expression(msg_l)
    if calc_result is not None:
        return calc_result

    # Кодові моди
    if msg_l in code_mods:
        try:
            return code_mods[msg_l]()
        except Exception as e:
            sed_print(f"DEBUG: Помилка виконання кодового моду '{msg_l}': {e}", "err")
            return f"Sed: Помилка виконання моду '{msg_l}': {e}"

    # Виконання функції з python_modules
    run_match = re.match(r"виконай\s+([^\s]+)(.*)", msg_l)
    if run_match:
        func_name = run_match.group(1)
        func_args = run_match.group(2).strip().split() if run_match.group(2).strip() else []
        for module in python_modules.values():
            func = getattr(module, func_name, None)
            if callable(func):
                try:
                    result = func(*func_args)
                    return f"Sed: Результат виконання '{func_name}': {result}"
                except Exception as e:
                    return f"Sed: Помилка виконання '{func_name}': {e}"
        return f"Sed: Функцію '{func_name}' не знайдено у модулях."

    # Пошук по базах (learned, ised, mods)
    search_databases = [learned_data, ised_data, mods_data]
    for d in search_databases:
        if msg_l in d:
            response = d[msg_l]
            response = response.replace("{current_time}", current_time_str_short)
            response = response.replace("{current_date}", datetime.datetime.now().strftime("%Y-%m-%d"))
            response = response.replace("{day_of_week}", datetime.datetime.now().strftime("%A"))
            if sed_has_code_error:
                response += " error code..."
            return response

    for d in search_databases:
        for k_original, v in d.items():
            if isinstance(k_original, str) and msg_l in k_original.lower():
                response = v
                if sed_has_code_error:
                    response += " error code..."
                return response
            if not isinstance(k_original, str):
                try:
                    if k_original.search(msg_l):
                        response = v
                        if sed_has_code_error:
                            response += " error code..."
                        return response
                except Exception:
                    continue

    approx_response = find_approximate_response(msg_l)
    if approx_response:
        resp = f"(≈) {approx_response}"
        if sed_has_code_error:
            resp += " error code..."
        return resp

    if msg_l not in unknown_data:
        unknown_data[msg_l] = ""
        save_json_safe(UNKNOWN_DATA_FILE, unknown_data)

    resp = "Вибач, не зрозумів."
    if sed_has_code_error:
        resp += " error code..."
    return resp

# ----------------- Допоміжні команди, які ти надавав -----------------
def simulate_ats_connection_failure():
    sed_print("Sed: Спроба підключення до АТС...", "debug")
    sed_print("error translity", "debug")
    sed_print("ATS перезавантажується", "debug")
    for _ in range(3):
        sed_print("error translity signal...", "debug")
        time.sleep(0.2)
    sed_print("no signal ATS\nATS не знайдено!\n--- Спроба завершена ---", "err")

def simulate_reboot():
    global sed_has_code_error
    sed_print("Sed: Перезавантаження...", "debug")
    time.sleep(0.3)
    report = ""
    try:
        with open(__file__, 'r', encoding='utf-8') as f:
            ast.parse(f.read())
        report = "Sed: Аналіз завершено. Помилок у коді не виявлено."
        sed_has_code_error = False
    except Exception as e:
        sed_has_code_error = True
        report = f"Sed: Виявлено проблему у коді: {e}"
    sed_print("Sed: Модулі завантажено.\n" + report, "debug")
    load_mods()

# ----------------- Функції для переліку/видалення модів (текст для chat) -----------------
def list_mods_text():
    if not mods_data and not code_mods and not python_modules:
        return "Sed: Моди не завантажено. Переконайтесь, що вони в папці 'mods'."
    response = "Sed: Завантажені моди:\n"
    # словникові
    dict_files = [f for f in sorted(os.listdir(MODS_FOLDER)) if f.endswith((".sed", ".txt"))]
    if dict_files:
        response += "  Словникові (.sed/.txt):\n"
        for fn in dict_files:
            response += f"    - {fn}\n"
    else:
        response += "  (Немає словникових модів)\n"
    # кодові
    if code_mods:
        response += "  Кодові (.sed.py):\n"
        for cmd_name in sorted(code_mods.keys()):
            response += f"    - {cmd_name}\n"
    else:
        response += "  (Немає кодових модів)\n"
    if python_modules:
        response += "  Допоміжні Python-модулі (.py):\n"
        for module_name in sorted(python_modules.keys()):
            response += f"    - {module_name}.py\n"
    else:
        response += ""
    return response.strip()

def delete_mod(identifier, mods_folder=MODS_FOLDER):
    try:
        files = [f for f in sorted(os.listdir(mods_folder)) if f.endswith((".py",".sed",".sed.py",".txt"))]
    except FileNotFoundError:
        sed_print("Папку з модами не знайдено.", "err")
        return
    try:
        if identifier.isdigit():
            idx = int(identifier) - 1
            if 0 <= idx < len(files):
                os.remove(os.path.join(mods_folder, files[idx]))
                sed_print(f"Мод {files[idx]} видалено.", "debug")
        else:
            if identifier in files:
                os.remove(os.path.join(mods_folder, identifier))
                sed_print(f"Мод {identifier} видалено.", "debug")
            else:
                file_path = os.path.join(mods_folder, identifier)
                if os.path.exists(file_path):
                    os.remove(file_path)
                    sed_print(f"Мод {identifier} видалено (знайдено напряму).", "debug")
                else:
                    sed_print(f"Файл {identifier} не знайдено для видалення.", "err")
    except Exception as e:
        sed_print(f"Помилка при видаленні: {e}", "err")

# ----------------- SYSTEM ANALYZER (SSA) — функція run_system_analyzer() -----------------
def run_system_analyzer():
    """Повний аналіз системи: файли, JSON, словники, моди, ядро. Логує в security_log.txt."""
    summary = {"ok": [], "warn": [], "err": []}
    sed_print("Sed: 📑 Починаю повний системний аналіз...", "debug")
    append_security_log("Запуск системного аналізу (📑)")

    # 1) Перевірка основних файлів / папок
    essentials = {
        "mods": MODS_FOLDER,
        "ised": ISED_LIBRARY_FILE,
        "atsed": ATSED_FILE,
        "learned": LEARNED_DATA_FILE,
        "unknown": UNKNOWN_DATA_FILE,
        "chat_log": CHAT_LOG_FILE
    }
    for key, path in essentials.items():
        if isinstance(path, str):
            p = Path(path)
        else:
            p = Path(path)
        if not p.exists():
            try:
                if p.suffix in (".json",):
                    save_json_safe(str(p), {})
                elif p.suffix in (".txt", ""):
                    p.parent.mkdir(parents=True, exist_ok=True)
                    p.write_text("", encoding="utf-8")
                summary["warn"].append(f"{p} не знайдено — створено новий.")
                sed_print(f"⚠️ Файл/папка '{p}' не знайдено — створено новий.", "err")
                append_security_log(f"WARNING: {p} not found — created.")
            except Exception as e:
                summary["err"].append(f"Не вдалося створити {p}: {e}")
                sed_print(f"❌ Не вдалося створити {p}: {e}", "err")
                append_security_log(f"ERROR: cannot create {p}: {e}")

    # 2) Перевірка JSON-файлів
    for jfile in [LEARNED_DATA_FILE, UNKNOWN_DATA_FILE]:
        try:
            _ = load_json_safe(jfile)
            summary["ok"].append(f"JSON {jfile} прочитано")
            sed_print(f"Sed: 🧾 JSON '{jfile}' прочитано.", "debug")
        except Exception as e:
            summary["err"].append(f"JSON {jfile} пошкоджено: {e}")
            sed_print(f"❌ JSON '{jfile}' пошкоджено: {e}", "err")
            append_security_log(f"ERROR: JSON {jfile} corrupted: {e}")

    # 3) Перевірка словників (.sed/.txt)
    if os.path.exists(ISED_LIBRARY_FILE):
        bad_lines = []
        try:
            with open(ISED_LIBRARY_FILE, "r", encoding="utf-8") as f:
                for i, line in enumerate(f, 1):
                    if line.strip() and ":" not in line:
                        bad_lines.append((i, line.strip()))
            if bad_lines:
                summary["warn"].append(f"{ISED_LIBRARY_FILE}: {len(bad_lines)} проблемних рядків")
                sed_print(f"⚠️ Словник {ISED_LIBRARY_FILE} має рядки без ':' ({len(bad_lines)})", "err")
                append_security_log(f"WARNING: {ISED_LIBRARY_FILE} format issues: {len(bad_lines)}")
            else:
                summary["ok"].append(f"{ISED_LIBRARY_FILE} OK")
                sed_print(f"Sed: Словник {ISED_LIBRARY_FILE} — перевірка пройдена.", "debug")
        except Exception as e:
            summary["err"].append(f"Не вдалося прочитати {ISED_LIBRARY_FILE}: {e}")
            sed_print(f"❌ Помилка читання {ISED_LIBRARY_FILE}: {e}", "err")
            append_security_log(f"ERROR: cannot read {ISED_LIBRARY_FILE}: {e}")

    # 4) Перевірка модів (всі типи) — імпортуємо у тестовому режимі
    mods_found = []
    if os.path.exists(MODS_FOLDER):
        for fn in sorted(os.listdir(MODS_FOLDER)):
            path = os.path.join(MODS_FOLDER, fn)
            if os.path.isfile(path):
                mods_found.append(fn)
                if fn.endswith((".sed", ".txt")):
                    # перевірити формат рядків
                    try:
                        with open(path, "r", encoding="utf-8") as f:
                            lines = [ln for ln in f if ln.strip()]
                        bad = [i for i, ln in enumerate(lines, 1) if ":" not in ln]
                        if bad:
                            summary["warn"].append(f"{fn}: форматні помилки")
                            sed_print(f"⚠️ Помилки формату у словниковому моді {fn}", "err")
                            append_security_log(f"WARNING: dict format {fn}")
                        else:
                            summary["ok"].append(fn)
                    except Exception as e:
                        summary["err"].append(f"{fn}: cannot read: {e}")
                        sed_print(f"❌ Не вдалося прочитати {fn}: {e}", "err")
                        append_security_log(f"ERROR: cannot read {fn}: {e}")

                elif fn.endswith(".sed.py"):
                    # тестове імпортування
                    try:
                        spec = importlib.util.spec_from_file_location(fn, path)
                        mod = importlib.util.module_from_spec(spec)
                        spec.loader.exec_module(mod)
                        # optional: check if has run_plugin
                        if hasattr(mod, 'run_plugin'):
                            summary["ok"].append(fn)
                            sed_print(f"Sed: ✅ Мод '{fn}' імпортовано і має run_plugin().", "debug")
                        else:
                            summary["warn"].append(f"{fn}: no run_plugin")
                            sed_print(f"Sed: ⚠️ Мод '{fn}' імпортовано, але run_plugin не знайдено.", "err")
                    except Exception as e:
                        summary["err"].append(f"{fn}: import error: {e}")
                        sed_print(f"❌ Помилка імпорту модa '{fn}': {e}", "err")
                        append_security_log(f"ERROR: import {fn}: {e}")

                elif fn.endswith(".py"):
                    try:
                        spec = importlib.util.spec_from_file_location(fn, path)
                        module = importlib.util.module_from_spec(spec)
                        spec.loader.exec_module(module)
                        summary["ok"].append(fn)
                        sed_print(f"Sed: ✅ Python-модуль '{fn}' імпортовано.", "debug")
                    except Exception as e:
                        summary["err"].append(f"{fn}: import error: {e}")
                        sed_print(f"❌ Помилка імпорту Python-модуля '{fn}': {e}", "err")
                        append_security_log(f"ERROR: import {fn}: {e}")

    else:
        sed_print(f"⚠️ Папка модів '{MODS_FOLDER}' відсутня.", "err")
        append_security_log(f"WARNING: mods folder missing.")

    # 5) Перевірка ядра (ast)
    try:
        with open(__file__, 'r', encoding='utf-8') as f:
            ast.parse(f.read())
        summary["ok"].append("Ядро AST OK")
        sed_print("Sed: 🧠 Ядро стабільне (AST OK).", "debug")
    except Exception as e:
        summary["err"].append(f"Ядро AST error: {e}")
        sed_print(f"❌ Синтаксична помилка у ядрі: {e}", "err")
        append_security_log(f"ERROR: core AST parse: {e}")

    # Підсумок
    ok_count = len(summary["ok"])
    warn_count = len(summary["warn"])
    err_count = len(summary["err"])
    sed_print("---- Резюме аналізу (📑) ----", "debug")
    sed_print(f"Активні / ОК: {ok_count}", "debug")
    sed_print(f"Попередження: {warn_count}", "err" if warn_count else "debug")
    sed_print(f"Помилки: {err_count}", "err" if err_count else "debug")
    append_security_log(f"ANALYZER summary OK={ok_count} WARN={warn_count} ERR={err_count}")

    if err_count == 0:
        return "Sed: 📑 Аналіз завершено. Система стабільна."
    else:
        return f"Sed: 📑 Аналіз завершено. Виявлено {err_count} помилок (див. security_log.txt)."

# ----------------- GUI -----------------
class SedGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"AT-S — Sed {VERSION}")
        self.geometry("1150x720")
        self.minsize(900, 600)
        self.protocol("WM_DELETE_WINDOW", self.on_close)

        # load config
        self.cfg = load_config()
        self.theme_name = self.cfg.get("theme", "light")
        self.mods_dir = Path(self.cfg.get("mods_dir", MODS_FOLDER))
        self.left_visible = bool(self.cfg.get("left_visible", True))
        self.mode = tk.StringVar(value=self.cfg.get("mode", "Користувач"))
        self.temporary_chat = False  # if True, messages aren't logged into system log

        # UI state
        self.cursor_blink = False
        self.technocursor_state = False
        self.stop_printer = threading.Event()

        self.create_widgets()
        self.apply_theme(initial=True)

        # start printer worker thread
        self.printer_thread = threading.Thread(target=queued_printer_worker, args=(self.output_text, self.stop_printer, lambda: self.theme_name), daemon=True)
        self.printer_thread.start()

        # initial data load
        threading.Thread(target=self.bootstrap_system, daemon=True).start()

    def create_widgets(self):
        # Top bar
        top = ttk.Frame(self)
        top.pack(side=tk.TOP, fill=tk.X, padx=6, pady=6)

        # Emojis buttons as requested (use those from v12)
        btn_change_theme = ttk.Button(top, text="🚥", width=3, command=self.cycle_theme)
        btn_change_theme.pack(side=tk.LEFT, padx=2)
        btn_analyze = ttk.Button(top, text="📑", width=3, command=self.on_analyze)
        btn_analyze.pack(side=tk.LEFT, padx=2)
        btn_save = ttk.Button(top, text="💾", width=3, command=self.on_save_snapshot)
        btn_save.pack(side=tk.LEFT, padx=2)
        btn_toggle_mode = ttk.Button(top, text="↔️", width=3, command=self.toggle_mode)
        btn_toggle_mode.pack(side=tk.LEFT, padx=2)
        btn_core_diag = ttk.Button(top, text="📄", width=3, command=self.on_core_diag)
        btn_core_diag.pack(side=tk.LEFT, padx=2)
        btn_temp_chat = ttk.Button(top, text="🔒", width=3, command=self.toggle_temporary_chat)
        btn_temp_chat.pack(side=tk.LEFT, padx=2)

        # Hide/show left panel button on top right
        self.btn_toggle_left = ttk.Button(top, text="⏩", width=3, command=self.toggle_left_panel)
        self.btn_toggle_left.pack(side=tk.RIGHT, padx=2)

        # Main paned window
        self.paned = ttk.PanedWindow(self, orient=tk.HORIZONTAL)
        self.paned.pack(fill=tk.BOTH, expand=True, padx=6, pady=6)

        # Left panel (mods and quick actions)
        self.left_frame = ttk.Frame(self.paned, width=300)
        self.left_frame.pack_propagate(False)
        lbl_folder = ttk.Label(self.left_frame, text="Папка модів:")
        lbl_folder.pack(anchor="w", padx=6, pady=(4,0))
        self.lbl_mods_dir = ttk.Label(self.left_frame, text=str(self.mods_dir), foreground="blue")
        self.lbl_mods_dir.pack(anchor="w", padx=6, pady=(0,6))

        self.files_listbox = tk.Listbox(self.left_frame)
        self.files_listbox.pack(fill=tk.BOTH, expand=True, padx=6, pady=6)
        self.files_listbox.bind("<<ListboxSelect>>", self.on_select_file)
        self.files_listbox.bind("<Button-3>", self.on_list_right_click)

        left_buttons = ttk.Frame(self.left_frame)
        left_buttons.pack(fill=tk.X, padx=6, pady=(0,6))
        ttk.Button(left_buttons, text="🔍", width=3, command=self.open_selected).pack(side=tk.LEFT, padx=2)
        ttk.Button(left_buttons, text="❓", width=3, command=self.on_analysis_help).pack(side=tk.LEFT, padx=2)
        ttk.Button(left_buttons, text="📂", width=3, command=self.change_mods_folder).pack(side=tk.LEFT, padx=2)
        ttk.Button(left_buttons, text="🧹", width=3, command=self.clear_logs_prompt).pack(side=tk.LEFT, padx=2)

        # Center frame (output)
        self.center_frame = ttk.Frame(self.paned)
        center_top = ttk.Frame(self.center_frame)
        center_top.pack(fill=tk.X)
        self.file_title = tk.StringVar(value="— файл не вибрано —")
        ttk.Label(center_top, textvariable=self.file_title, font=("TkDefaultFont", 11, "bold")).pack(side=tk.LEFT, padx=6, pady=6)
        self.status_label = ttk.Label(center_top, text="")
        self.status_label.pack(side=tk.RIGHT, padx=6)

        # Output text (read-only) — here Sed prints all startup messages and responses
        self.output_text = tk.Text(self.center_frame, wrap="word", state="disabled")
        self.output_text.pack(fill=tk.BOTH, expand=True, padx=6, pady=(0,6))
        yscr = ttk.Scrollbar(self.center_frame, orient=tk.VERTICAL, command=self.output_text.yview)
        yscr.pack(side=tk.RIGHT, fill=tk.Y)
        self.output_text.configure(yscrollcommand=yscr.set)

        # tags for styling
        self.output_text.tag_configure("debug", foreground="#888888")
        self.output_text.tag_configure("info", foreground="#ffffff")
        self.output_text.tag_configure("err", foreground="#ff6b6b")
        self.output_text.tag_configure("sed", foreground="#00ff6a")  # techno green accent

        # Input area at bottom
        bottom = ttk.Frame(self)
        bottom.pack(side=tk.BOTTOM, fill=tk.X, padx=6, pady=6)
        ttk.Label(bottom, text="Ввід:").pack(side=tk.LEFT, padx=(0,6))
        self.input_entry = ttk.Entry(bottom)
        self.input_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0,6))
        self.input_entry.bind("<Return>", self.on_input_submit)
        ttk.Button(bottom, text="➡️", width=5, command=self.on_input_submit).pack(side=tk.LEFT)

        # Add frames to paned window
        self.paned.add(self.left_frame, weight=1)
        self.paned.add(self.center_frame, weight=4)

        # place techno cursor label (hidden initially)
        self.cursor_label = tk.Label(self.center_frame, text="_", font=("Courier", 12))
        self.cursor_label.place_forget()

    # ----------------- Theme handling -----------------
    def apply_theme(self, initial=False):
        theme = THEMES.get(self.theme_name, THEMES["light"])
        self.configure(bg=theme["bg"])
        style = ttk.Style()
        try:
            style.configure("TFrame", background=theme["bg"])
            style.configure("TLabel", background=theme["bg"], foreground=theme["fg"])
            style.configure("TButton", background=theme["button_bg"], foreground=theme["fg"])
            style.configure("TEntry", fieldbackground=theme["code_bg"], foreground=theme["fg"])
        except Exception:
            pass
        self.output_text.configure(bg=theme["code_bg"], fg=theme["fg"], insertbackground=theme["fg"])
        self.lbl_mods_dir.configure(background=theme["bg"], foreground=theme["accent"])
        # tags background adjustments (keep readable)
        # start/stop techno cursor
        if self.theme_name == "techno":
            self.start_techno_cursor()
        else:
            self.stop_techno_cursor()
        # save config
        self.cfg["theme"] = self.theme_name
        self.cfg["mods_dir"] = str(self.mods_dir)
        self.cfg["left_visible"] = self.left_visible
        self.cfg["mode"] = self.mode.get()
        save_config(self.cfg)

    def cycle_theme(self):
        keys = list(THEMES.keys())
        idx = keys.index(self.theme_name)
        self.theme_name = keys[(idx + 1) % len(keys)]
        # immediate apply (no blocking)
        self.apply_theme()

    # Techno cursor
    def start_techno_cursor(self):
        if self.cursor_blink:
            return
        self.cursor_blink = True
        def place_cursor():
            try:
                self.cursor_label.place(relx=0.995, rely=0.015, anchor="ne")
                self.cursor_label.configure(fg=THEMES["techno"]["fg"], bg=THEMES["techno"]["bg"])
            except Exception:
                pass
        place_cursor()
        def blink():
            if not self.cursor_blink:
                self.cursor_label.place_forget()
                return
            self.technocursor_state = not self.technocursor_state
            self.cursor_label.configure(text="_" if self.technocursor_state else " ")
            self.after(500, blink)
        blink()

    def stop_techno_cursor(self):
        self.cursor_blink = False
        self.cursor_label.place_forget()

    # ----------------- Bootstrap system: load data + startup messages -----------------
    def bootstrap_system(self):
        global ised_data, learned_data, atsed_data, unknown_data
        # load persistent data
        ised_data = load_data(ISED_LIBRARY_FILE)
        atsed_data = load_data(ATSED_FILE, as_regex=True)
        learned_data = load_json_safe(LEARNED_DATA_FILE)
        unknown_data = load_json_safe(UNKNOWN_DATA_FILE)
        load_mods(self.mods_dir)

        # print startup sequence EXACTLY as provided (kept)
        lines = [
            "DEBUG: Завантажую словниковий мод: ased.sed",
            "DEBUG: Завантажено Python-модуль: evaporation",
            "DEBUG: Завантажено кодовий мод: import time",
            "DEBUG: Завантажено кодовий мод: pixelart",
            "DEBUG: evaporation.py завантажено через exec()",
            "DEBUG: Завантажено кодовий мод: Sed-core",
            "DEBUG: Завантажую словниковий мод: sedworld.sed",
            "DEBUG: Завантажено кодовий мод: асед",
            f"Sed {VERSION} від {AUTHOR} готовий. Введи команду або 'допомога'."
        ]
        for ln in lines:
            sed_print(ln, "debug" if ln.startswith("DEBUG") else "sed")

    # ----------------- Left panel handlers -----------------
    def toggle_left_panel(self):
        if self.left_visible:
            try:
                self.paned.forget(self.left_frame)
            except Exception:
                pass
            self.left_visible = False
            self.btn_toggle_left.configure(text="⏪")
        else:
            try:
                self.paned.insert(0, self.left_frame)
            except Exception:
                pass
            self.left_visible = True
            self.btn_toggle_left.configure(text="⏩")
        self.cfg["left_visible"] = self.left_visible
        save_config(self.cfg)

    def change_mods_folder(self):
        d = filedialog.askdirectory(initialdir=str(self.mods_dir))
        if d:
            self.mods_dir = Path(d)
            self.lbl_mods_dir.config(text=str(self.mods_dir))
            self.cfg["mods_dir"] = str(self.mods_dir)
            save_config(self.cfg)
            load_mods(str(self.mods_dir))
            self.refresh_mods_list()

    def refresh_mods_list(self):
        self.files_listbox.delete(0, tk.END)
        try:
            items = sorted(Path(self.mods_dir).rglob("*"))
        except Exception:
            items = []
        for it in items:
            if it.is_file():
                try:
                    rel = it.relative_to(self.mods_dir)
                except Exception:
                    rel = it
                self.files_listbox.insert(tk.END, str(rel))

    def on_select_file(self, event=None):
        sel = self.files_listbox.curselection()
        if not sel:
            return
        rel = self.files_listbox.get(sel[0])
        p = Path(self.mods_dir) / rel
        self.file_title.set(str(rel))
        try:
            content = p.read_text(encoding="utf-8")
            sed_print(f"Sed: Відкрито файл {rel}", "debug")
            # show code in popup
            dlg = tk.Toplevel(self)
            dlg.title(f"Код: {rel}")
            txt = tk.Text(dlg, wrap="none")
            txt.insert("1.0", content)
            txt.pack(fill=tk.BOTH, expand=True)
            ttk.Button(dlg, text="Закрити", command=dlg.destroy).pack()
        except Exception as e:
            sed_print(f"Sed: Помилка читання {rel}: {e}", "err")

    def open_selected(self):
        self.on_select_file()

    def on_list_right_click(self, event):
        try:
            idx = self.files_listbox.nearest(event.y)
            if idx is not None:
                self.files_listbox.selection_clear(0, tk.END)
                self.files_listbox.selection_set(idx)
                self.files_listbox.activate(idx)
                popup = tk.Menu(self, tearoff=0)
                popup.add_command(label="Відкрити", command=self.open_selected)
                popup.add_command(label="Аналіз ❓", command=self.on_analysis_help)
                popup.tk_popup(event.x_root, event.y_root)
        finally:
            try:
                popup.grab_release()
            except Exception:
                pass

    # ----------------- Input handling -----------------
    def on_input_submit(self, event=None):
        user_text = self.input_entry.get().strip()
        if not user_text:
            return
        # If temporary chat — do not log into persistent logs
        if not self.temporary_chat:
            # write to chat log file
            try:
                with open(CHAT_LOG_FILE, "a", encoding="utf-8") as f:
                    f.write(f"[{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] User: {user_text}\n")
            except Exception:
                logging.exception("Cannot write to chat log")

        sed_print(f"Ти: {user_text}", "info")
        # save history
        chat_history.append(user_text)
        # get response (on main thread to keep sequence)
        try:
            resp = get_response(user_text)
            sed_print(resp, "sed" if resp.startswith("Sed:") else "info")
            # save response into system log already handled by queued_printer_worker -> logging
            if not self.temporary_chat:
                try:
                    with open(CHAT_LOG_FILE, "a", encoding="utf-8") as f:
                        f.write(f"[{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {AI_NAME}: {resp}\n")
                except Exception:
                    logging.exception("Cannot write to chat log")
            # if command is exit, close
            if user_text.lower() == "вийти":
                self.on_close()
        except Exception as e:
            sed_print(f"DEBUG: Помилка при обробці вводу: {e}", "err")
        finally:
            self.input_entry.delete(0, tk.END)

    # ----------------- Buttons callbacks -----------------
    def on_analyze(self):
        # Run analyzer in background to keep GUI responsive
        def worker():
            res = run_system_analyzer()
            sed_print(res, "sed")
        threading.Thread(target=worker, daemon=True).start()

    def on_save_snapshot(self):
        # Save simple snapshot: config + list of mods + system log copy
        try:
            snapshot_dir = Path("snapshot")
            snapshot_dir.mkdir(exist_ok=True)
            # save config
            save_config(self.cfg)
            # copy system log
            try:
                with open(SYSTEM_LOG_FILE, "r", encoding="utf-8") as src, open(snapshot_dir / "system.log", "w", encoding="utf-8") as dst:
                    dst.write(src.read())
            except Exception:
                pass
            # save mods list
            with open(snapshot_dir / "mods_list.txt", "w", encoding="utf-8") as f:
                for fn in sorted(os.listdir(MODS_FOLDER)) if os.path.exists(MODS_FOLDER) else []:
                    f.write(fn + "\n")
            sed_print("Sed: Збережено snapshot у папці 'snapshot'.", "debug")
        except Exception as e:
            sed_print(f"Sed: Помилка при створенні snapshot: {e}", "err")

    def toggle_mode(self):
        cur = self.mode.get()
        new = "Розробник" if cur == "Користувач" else "Користувач"
        self.mode.set(new)
        self.cfg["mode"] = new
        save_config(self.cfg)
        sed_print(f"Sed: Режим змінено на {new}", "debug")

    def on_core_diag(self):
        # Quick core diagnostics (ast parse + loaded mods summary)
        try:
            with open(__file__, 'r', encoding='utf-8') as f:
                ast.parse(f.read())
            sed_print("Sed: Ядро AST — OK", "debug")
        except Exception as e:
            sed_print(f"Sed: Помилка AST: {e}", "err")
        # report loaded modules
        sed_print(list_mods_text(), "debug")

    def toggle_temporary_chat(self):
        self.temporary_chat = not self.temporary_chat
        sed_print(f"Sed: Тимчасовий чат {'увімкнено' if self.temporary_chat else 'вимкнено'}", "debug")

    def on_analysis_help(self):
        # show details for selected file
        sel = self.files_listbox.curselection()
        if not sel:
            messagebox.showinfo("Діагностика", "Файл не обрано.")
            return
        rel = self.files_listbox.get(sel[0])
        p = Path(self.mods_dir) / rel
        try:
            # attempt to import and capture errors
            try:
                spec = importlib.util.spec_from_file_location(rel, str(p))
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                message = f"Мод {rel} імпортовано успішно."
            except Exception as e:
                message = f"Помилка при імпорті {rel}:\n{e}\n\nTraceback:\n{traceback.format_exc()}"
            dlg = tk.Toplevel(self)
            dlg.title("Діагностика моду")
            txt = tk.Text(dlg, wrap="word", width=100, height=30)
            txt.pack(fill=tk.BOTH, expand=True)
            txt.insert("1.0", message)
            ttk.Button(dlg, text="Закрити", command=dlg.destroy).pack(pady=6)
        except Exception as e:
            sed_print(f"DEBUG: on_analysis_help error: {e}", "err")

    def clear_logs_prompt(self):
        if messagebox.askyesno("Очистити лог", "Очистити system.log?"):
            clear_system_log()

    # ----------------- Shutdown -----------------
    def on_close(self):
        self.stop_printer.set()
        self.stop_printer = threading.Event()  # ensure worker stops
        # save config
        self.cfg["theme"] = self.theme_name
        self.cfg["mods_dir"] = str(self.mods_dir)
        self.cfg["left_visible"] = self.left_visible
        self.cfg["mode"] = self.mode.get()
        save_config(self.cfg)
        try:
            self.stop_printer.set()
        except Exception:
            pass
        self.destroy()

# ----------------- Entry point -----------------
def main():
    # ensure folders exist
    Path(MODS_FOLDER).mkdir(parents=True, exist_ok=True)
    LOGS_DIR.mkdir(parents=True, exist_ok=True)

    # create and run GUI
    app = SedGUI()

    # connect printer worker event stop to app
    app.stop_printer = threading.Event()
    # start a background thread for the queued_printer_worker already done in GUI init

    # run the mainloop
    app.mainloop()

if __name__ == "__main__":
    main()