import time
import math
from datetime import datetime
import sys
import os

# 🔐 Правильний шлях до evaporation.py — просто поруч із цим файлом
mods_path = os.path.dirname(__file__)  # ← тепер без "mods/mods"
evaporation_path = os.path.join(mods_path, "evaporation.py")
run_evaporation_module = None

try:
    with open(evaporation_path, "r", encoding="utf-8") as f:
        exec(f.read())  # напряму виконуємо код evaporation.py
    print("DEBUG: evaporation.py завантажено через exec()")
except Exception as e:
    print(f"❌ Помилка завантаження evaporation.py: {e}")

COMMAND_NAME = "вичесли"

def log_and_print(text):
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open("chat_log.txt", "a", encoding="utf-8") as f:
        f.write(f"[{now}] Sed: {text}\n")
    print(f"Sed:{text}")

def calculate_planet_time(blackhole_days, mass, radius):
    G = 6.67430e-11
    c = 299792458
    try:
        factor = math.sqrt(1 - (2 * G * mass) / (radius * c ** 2))
        if factor <= 0:
            factor = 0.0001
    except:
        factor = 0.0001
    planet_days = blackhole_days * factor
    planet_hours = planet_days * 24
    return factor, planet_days, planet_hours

def run_plugin():
    log_and_print("🌀 Модуль викривлення часу активовано")

    try:
        blackhole_days = float(input("🔍 Скільки днів пройшло біля чорної діри? → "))
    except:
        print("Sed: ❌ Невірне значення.")
        return

    print("🌌 Обрати рівень викривлення:")
    print("1 — слабке")
    print("2 — середнє")
    print("3 — екстремальне")
    level = input("Рівень [1–3]: ").strip()

    if level == "1":
        mass = 2e30
        radius = 1e10
        spin = 0.01
    elif level == "2":
        mass = 5e35
        radius = 5e8
        spin = 0.3
    elif level == "3":
        mass = 1e39
        radius = 1e6
        spin = 1.2
    else:
        mass = 5e35
        radius = 5e8
        spin = 0.3

    # 🔥 Якщо днів забагато — передаємо в модуль evaporation
    if blackhole_days >= 1e15:
        print("⚠️ Надмірна тривалість симуляції.")
        if run_evaporation_module:
            print("☁️ Перекидання до модуля 'випаровування'")
            run_evaporation_module(blackhole_days, mass)
        else:
            print("❌ evaporation.py недоступний. Неможливо обрахувати втрату маси.")
        return

    print(f"🕳️ Симулюється чорна діра ({blackhole_days} днів)...")
    time.sleep(1.2)
    print("🔭 Формується проекція...")
    time.sleep(1.1)

    factor, planet_days, planet_hours = calculate_planet_time(blackhole_days, mass, radius)

    print("🧮 Результати:")
    print(f"🌌 Коефіцієнт викривлення: {factor:.6f}")
    print(f"🕳️ Чорна діра: {blackhole_days} днів")
    print(f"🌍 Планета: {planet_hours:.2f} годин ({planet_days:.6f} днів)")

    oberts_dira = blackhole_days * spin
    oberts_planeta = planet_days * spin
    print(f"🔁 Обертів чорної діри: {oberts_dira:.2f}")
    print(f"🌀 З точки зору планети: {oberts_planeta:.6f}")
    if oberts_planeta < 0.001:
        print("⚠️ На планеті спостерігається майже нерухомість обертання...")

    log_and_print("✔️ Проекція завершена.")