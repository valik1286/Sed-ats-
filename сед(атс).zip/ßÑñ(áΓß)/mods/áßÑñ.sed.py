import sys
import time
from datetime import datetime

VERSION = "1.2"
COMMAND_NAME = "error translity"

def log_and_print(text):
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open("chat_log.txt", "a", encoding="utf-8") as f:
        f.write(f"[{now}] Sed: {text}\n")
    print(f"Sed:{text}")

def run_plugin():
    log_and_print("error signal connect...")
    log_and_print("error connect...")
    print("error signal sed...")
    print("error connect signal")
    time.sleep(1.5)
    print("error...")
    time.sleep(3)
    for i in range(5):
        print("error connect...")
        time.sleep(2.5)
    print("error translity")
    time.sleep(0.1)

    # фінальне повідомлення в лог
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open("chat_log.txt", "a", encoding="utf-8") as f:
        f.write(f"[{now}] Sed: Виявлено критичну помилку. Sed припинив роботу.\n")

    sys.exit(0)
