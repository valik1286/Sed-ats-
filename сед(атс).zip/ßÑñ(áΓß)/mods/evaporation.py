import math

def run_evaporation_module(days, mass):
    print("\n🧬 Sed-модуль 'випаровування' активовано")

    # Час життя чорної діри по формулі Гокінга:
    G = 6.67430e-11
    hbar = 1.054571817e-34
    c = 299792458

    lifetime_seconds = (5120 * math.pi * G**2 * mass**3) / (hbar * c**4)
    lifetime_days = lifetime_seconds / 86400

    # Втрата маси (приблизно)
    percent_lost = min((days / lifetime_days) * 100, 100)

    print(f"🕳️ Вік чорної діри: {days:.2e} днів")
    print(f"⏳ Теоретичний час життя: {lifetime_days:.2e} днів")
    print(f"📉 Втрачено маси: ~{percent_lost:.2f}%")

    if percent_lost >= 100:
        print("💥 Чорна діра випарувалась. Залишилось тільки інформаційне ехо.")
    elif percent_lost > 50:
        print("🌌 Діра слабшає. Простір дестабілізується...")
    else:
        print("☁️ Випаровування в процесі, маса ще достатня.")

    print("✔️ Розрахунок завершено.\n")